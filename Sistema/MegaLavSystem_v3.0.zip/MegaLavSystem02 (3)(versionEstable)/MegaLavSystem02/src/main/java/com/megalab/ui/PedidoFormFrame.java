package com.megalab.ui;

import com.megalab.model.Cliente;
import com.megalab.model.DetallePedido;
import com.megalab.model.Pedido;
import com.megalab.model.Servicio;
import com.megalab.model.TipoDetalle;
import com.megalab.service.ClienteService;
import com.megalab.service.PedidoService;
import com.megalab.service.ServicioService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class PedidoFormFrame extends JFrame {

    // ── Combos ──────────────────────────────────────────
    private JComboBox<String>      cbClientePlaceholder; // solo para mostrar hint
    private JComboBox<Cliente>     cbClientes;
    private JComboBox<String>      cbServicioPlaceholder;
    private JComboBox<Servicio>    cbServicios;
    private JComboBox<String>      cbTipoPlaceholder;
    private JComboBox<TipoDetalle> cbTipos;

    // ── Campos ──────────────────────────────────────────
    private JTextField  txtFechaRegistro;
    private JTextField  txtFechaEntrega;   // muestra la fecha seleccionada
    private JButton     btnCalendario;
    private JTextField  txtCantidad;       // solo enteros
    private JTextArea   txtObservaciones;

    // ── Tabla detalles ───────────────────────────────────
    private JTable             tablaDetalles;
    private DefaultTableModel  modeloDetalles;

    // ── Botones ──────────────────────────────────────────
    private JButton btnAgregarDetalle;
    private JButton btnEliminarDetalle;
    private JButton btnGuardarPedido;
    private JButton btnCancelar;

    // ── Label total ──────────────────────────────────────
    private JLabel lblTotal;

    // ── Servicios ────────────────────────────────────────
    private ClienteService clienteService = new ClienteService();
    private PedidoService   pedidoService   = new PedidoService();
    private ServicioService servicioService = new ServicioService();

    // ── Estado ───────────────────────────────────────────
    private List<DetallePedido> detallesTemp = new ArrayList<>();
    private PedidoFrame         pedidoFrame;

    // Fecha seleccionada via calendario
    private LocalDate fechaEntregaSeleccionada = null;

    // ════════════════════════════════════════════════════
    //  Constructor
    // ════════════════════════════════════════════════════

    public PedidoFormFrame(PedidoFrame pedidoFrame) {
        this.pedidoFrame = pedidoFrame;
        initUI();
    }

    // ════════════════════════════════════════════════════
    //  UI
    // ════════════════════════════════════════════════════

    private void initUI() {

        setTitle("MegaLav System - Nuevo Pedido");
        setSize(1100, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fondo = new Color(245, 247, 250);
        Color texto = new Color(44,  62,  80);
        Color verde = new Color(46,  204, 113);
        Color rojo  = new Color(231, 76,  60);
        Color azul  = new Color(52,  152, 219);
        Color gris  = new Color(149, 165, 166);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(fondo);

        // ── HEADER ────────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(fondo);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(new EmptyBorder(20, 20, 10, 20));

        JLabel titulo    = new JLabel("NUEVO PEDIDO");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titulo.setForeground(texto);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Registro y gestión de servicios de lavandería");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitulo.setForeground(Color.GRAY);
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(titulo);
        header.add(Box.createVerticalStrut(8));
        header.add(subtitulo);

        // ── PANEL DATOS GENERALES ─────────────────────────
        JPanel panelDatos = new JPanel(new GridBagLayout());
        panelDatos.setBackground(Color.WHITE);
        panelDatos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Datos del Pedido"),
                new EmptyBorder(10, 15, 10, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        // Combo clientes — empieza con hint vacío
        cbClientes = new JComboBox<>();
        cbClientes.insertItemAt(null, 0);   // índice 0 = sin selección
        cbClientes.setSelectedIndex(0);

        // Campos de fecha
        txtFechaRegistro = new JTextField(LocalDate.now().toString());
        txtFechaRegistro.setEditable(false);
        txtFechaRegistro.setBackground(new Color(235, 235, 235));

        // Campo fecha entrega (solo lectura, se llena con calendario)
        txtFechaEntrega = new JTextField(16);
        txtFechaEntrega.setEditable(false);
        txtFechaEntrega.setBackground(new Color(235, 235, 235));
        txtFechaEntrega.setToolTipText("Haga clic en 📅 para elegir la fecha");

        btnCalendario = new JButton("📅");
        btnCalendario.setToolTipText("Seleccionar fecha de entrega");
        btnCalendario.addActionListener(e -> abrirCalendario());

        JPanel panelFechaEntrega = new JPanel(new BorderLayout(4, 0));
        panelFechaEntrega.setBackground(Color.WHITE);
        panelFechaEntrega.add(txtFechaEntrega, BorderLayout.CENTER);
        panelFechaEntrega.add(btnCalendario,   BorderLayout.EAST);

        txtObservaciones = new JTextArea(3, 20);
        txtObservaciones.setLineWrap(true);
        txtObservaciones.setWrapStyleWord(true);
        JScrollPane scrollObs = new JScrollPane(txtObservaciones);

        // fila 0 – Cliente
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        panelDatos.add(new JLabel("Cliente:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        panelDatos.add(cbClientes, gbc);

        // fila 1 – Fechas
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panelDatos.add(new JLabel("Fecha Registro:"), gbc);
        gbc.gridx = 1;
        panelDatos.add(txtFechaRegistro, gbc);
        gbc.gridx = 2;
        panelDatos.add(new JLabel("Fecha Entrega:"), gbc);
        gbc.gridx = 3;
        panelDatos.add(panelFechaEntrega, gbc);

        // fila 2 – Observaciones
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        panelDatos.add(new JLabel("Observaciones:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        panelDatos.add(scrollObs, gbc);

        // ── PANEL AGREGAR SERVICIO ────────────────────────
        JPanel panelServicio = new JPanel(new GridBagLayout());
        panelServicio.setBackground(Color.WHITE);
        panelServicio.setBorder(BorderFactory.createTitledBorder("Agregar Servicio al Pedido"));

        GridBagConstraints s = new GridBagConstraints();
        s.insets = new Insets(8, 10, 8, 10);
        s.fill   = GridBagConstraints.HORIZONTAL;

        // Combos con hint vacío (sin selección inicial)
        cbServicios = new JComboBox<>();
        cbServicios.insertItemAt(null, 0);
        cbServicios.setSelectedIndex(0);

        cbTipos = new JComboBox<>();
        cbTipos.insertItemAt(null, 0);
        cbTipos.setSelectedIndex(0);

        // Campo cantidad — solo enteros (filtra teclas no numéricas)
        txtCantidad = new JTextField(8);
        txtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                char c = e.getKeyChar();
                // Permitir solo dígitos (0-9)
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });

        btnAgregarDetalle = crearBoton("✚ Agregar al Pedido", verde);

        s.gridx = 0; s.gridy = 0; panelServicio.add(new JLabel("Servicio:"), s);
        s.gridx = 1; panelServicio.add(cbServicios, s);
        s.gridx = 2; panelServicio.add(new JLabel("Tipo:"), s);
        s.gridx = 3; panelServicio.add(cbTipos, s);
        s.gridx = 4; panelServicio.add(new JLabel("Cantidad:"), s);
        s.gridx = 5; panelServicio.add(txtCantidad, s);
        s.gridx = 6; panelServicio.add(btnAgregarDetalle, s);

        // ── TABLA DETALLES ────────────────────────────────
        modeloDetalles = new DefaultTableModel(
                new String[]{"#", "Servicio", "Tipo", "Cantidad"},
                0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaDetalles = new JTable(modeloDetalles);
        tablaDetalles.setRowHeight(28);
        tablaDetalles.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaDetalles.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tablaDetalles.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaDetalles.getColumnModel().getColumn(0).setMaxWidth(40);

        JScrollPane scrollTabla = new JScrollPane(tablaDetalles);
        scrollTabla.setPreferredSize(new Dimension(0, 180));

        // Label total de prendas/unidades (no de filas)
        lblTotal = new JLabel("Total de unidades: 0");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTotal.setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel panelTablaConTotal = new JPanel(new BorderLayout());
        panelTablaConTotal.setBackground(fondo);
        panelTablaConTotal.add(scrollTabla, BorderLayout.CENTER);
        panelTablaConTotal.add(lblTotal,    BorderLayout.SOUTH);

        // ── BOTONES PRINCIPALES ───────────────────────────
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.setBackground(fondo);

        btnEliminarDetalle = crearBoton("✖ Eliminar Ítem",   rojo);
        btnGuardarPedido   = crearBoton("💾 Guardar Pedido",  azul);
        btnCancelar        = crearBoton("Cancelar",           gris);

        panelBotones.add(btnEliminarDetalle);
        panelBotones.add(btnGuardarPedido);
        panelBotones.add(btnCancelar);

        // ── ENSAMBLADO ────────────────────────────────────
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(fondo);
        panelSuperior.add(panelDatos,    BorderLayout.NORTH);
        panelSuperior.add(panelServicio, BorderLayout.SOUTH);

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(fondo);
        centro.setBorder(new EmptyBorder(15, 20, 10, 20));
        centro.add(panelSuperior,      BorderLayout.NORTH);
        centro.add(panelTablaConTotal, BorderLayout.CENTER);
        centro.add(panelBotones,       BorderLayout.SOUTH);

        principal.add(header, BorderLayout.NORTH);
        principal.add(centro, BorderLayout.CENTER);
        add(principal);

        // ── CARGA INICIAL ─────────────────────────────────
        cargarClientes();
        cargarServicios();

        // ── EVENTOS ───────────────────────────────────────
        cbServicios.addActionListener(e -> cargarTipos());
        btnAgregarDetalle.addActionListener(e -> agregarDetalle());
        btnEliminarDetalle.addActionListener(e -> eliminarDetalle());
        btnGuardarPedido.addActionListener(e -> guardarPedido());
        btnCancelar.addActionListener(e -> dispose());
    }

    // ════════════════════════════════════════════════════
    //  CALENDARIO EMERGENTE
    // ════════════════════════════════════════════════════

    private void abrirCalendario() {

        JDialog dlg = new JDialog(this, "Seleccionar Fecha de Entrega", true);
        dlg.setSize(320, 280);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        // Partir de la fecha ya seleccionada o de hoy
        Calendar cal = Calendar.getInstance();
        if (fechaEntregaSeleccionada != null) {
            cal.set(fechaEntregaSeleccionada.getYear(),
                    fechaEntregaSeleccionada.getMonthValue() - 1,
                    fechaEntregaSeleccionada.getDayOfMonth());
        }

        // ── Spinners año/mes ──────────────────────────────
        int anioActual = cal.get(Calendar.YEAR);

        SpinnerNumberModel modeloAnio = new SpinnerNumberModel(
                anioActual, anioActual, anioActual + 5, 1
        );
        JSpinner spinAnio = new JSpinner(modeloAnio);

        String[] meses = {
                "Enero","Febrero","Marzo","Abril","Mayo","Junio",
                "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
        };
        JComboBox<String> cbMes = new JComboBox<>(meses);
        cbMes.setSelectedIndex(cal.get(Calendar.MONTH));

        JPanel panelNav = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        panelNav.add(cbMes);
        panelNav.add(spinAnio);

        // ── Grid de días ──────────────────────────────────
        JPanel gridDias = new JPanel(new GridLayout(0, 7, 4, 4));
        gridDias.setBorder(new EmptyBorder(4, 10, 4, 10));

        // Encabezados
        String[] encDias = {"D","L","M","M","J","V","S"};
        for (String d : encDias) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            gridDias.add(lbl);
        }

        // Celda seleccionada
        final int[] diaSeleccionado = { cal.get(Calendar.DAY_OF_MONTH) };
        final JButton[] botonesDias = new JButton[42];

        Runnable rellenarGrid = () -> {
            // Limpia botones anteriores (mantiene los 7 encabezados)
            int total = gridDias.getComponentCount();
            for (int i = total - 1; i >= 7; i--) {
                gridDias.remove(i);
            }

            int anio = (int) spinAnio.getValue();
            int mes  = cbMes.getSelectedIndex(); // 0=enero

            Calendar tmp = Calendar.getInstance();
            tmp.set(anio, mes, 1);

            int primerDia = tmp.get(Calendar.DAY_OF_WEEK) - 1; // 0=dom
            int totalDias = tmp.getActualMaximum(Calendar.DAY_OF_MONTH);

            // Celdas vacías antes del primer día
            for (int i = 0; i < primerDia; i++) {
                gridDias.add(new JLabel(""));
            }

            LocalDate hoy = LocalDate.now();

            for (int dia = 1; dia <= totalDias; dia++) {
                final int d = dia;
                LocalDate fechaDia = LocalDate.of(anio, mes + 1, dia);
                JButton btn = new JButton(String.valueOf(dia));
                btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                btn.setFocusPainted(false);
                btn.setMargin(new Insets(2, 2, 2, 2));

                boolean esPasado = fechaDia.isBefore(hoy);

                if (esPasado) {
                    btn.setEnabled(false);
                    btn.setBackground(new Color(230, 230, 230));
                } else {
                    if (d == diaSeleccionado[0] &&
                            mes + 1 == (fechaEntregaSeleccionada != null ?
                                    fechaEntregaSeleccionada.getMonthValue() : -1) &&
                            anio == (fechaEntregaSeleccionada != null ?
                                    fechaEntregaSeleccionada.getYear() : -1)) {
                        btn.setBackground(new Color(52, 152, 219));
                        btn.setForeground(Color.WHITE);
                    }

                    btn.addActionListener(ev -> {
                        int anioSel = (int) spinAnio.getValue();
                        int mesSel  = cbMes.getSelectedIndex() + 1;
                        fechaEntregaSeleccionada = LocalDate.of(anioSel, mesSel, d);
                        txtFechaEntrega.setText(
                                fechaEntregaSeleccionada.format(
                                        DateTimeFormatter.ofPattern("dd/MM/yyyy")
                                )
                        );
                        dlg.dispose();
                    });
                }
                gridDias.add(btn);
            }

            gridDias.revalidate();
            gridDias.repaint();
        };

        rellenarGrid.run();

        spinAnio.addChangeListener(e -> rellenarGrid.run());
        cbMes.addActionListener(e  -> rellenarGrid.run());

        JScrollPane scrollGrid = new JScrollPane(gridDias);
        scrollGrid.setBorder(null);

        dlg.setLayout(new BorderLayout());
        dlg.add(panelNav,   BorderLayout.NORTH);
        dlg.add(scrollGrid, BorderLayout.CENTER);

        dlg.setVisible(true);
    }

    // ════════════════════════════════════════════════════
    //  LÓGICA DE DETALLES
    // ════════════════════════════════════════════════════

    private void agregarDetalle() {

        // Validar selección de servicio
        Servicio servicio = (Servicio) cbServicios.getSelectedItem();
        if (servicio == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un servicio.", "Dato faltante",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validar selección de tipo
        TipoDetalle tipo = (TipoDetalle) cbTipos.getSelectedItem();
        if (tipo == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un tipo.", "Dato faltante",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validar cantidad (entero > 0)
        String cantStr = txtCantidad.getText().trim();
        if (cantStr.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese la cantidad.", "Dato faltante",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(cantStr);
            if (cantidad <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "La cantidad debe ser un número entero mayor a 0.",
                    "Valor inválido", JOptionPane.ERROR_MESSAGE);
            return;
        }

        DetallePedido detalle = new DetallePedido(
                servicio.getIdServicio(),
                tipo.getIdTipo(),
                cantidad,
                servicio.getNombre(),
                tipo.getNombre()
        );

        detallesTemp.add(detalle);
        modeloDetalles.addRow(new Object[]{
                detallesTemp.size(),
                servicio.getNombre(),
                tipo.getNombre(),
                cantidad
        });

        actualizarTotal();
        txtCantidad.setText("");
        txtCantidad.requestFocus();
    }

    private void eliminarDetalle() {

        int fila = tablaDetalles.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un ítem de la tabla para eliminar.",
                    "Sin selección", JOptionPane.WARNING_MESSAGE);
            return;
        }

        detallesTemp.remove(fila);
        modeloDetalles.removeRow(fila);

        // Renumerar columna #
        for (int i = 0; i < modeloDetalles.getRowCount(); i++) {
            modeloDetalles.setValueAt(i + 1, i, 0);
        }

        actualizarTotal();
    }

    private void guardarPedido() {

        // Cliente
        if (cbClientes.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un cliente.", "Dato faltante",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Detalles no vacíos
        if (detallesTemp.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Debe agregar al menos un servicio al pedido.",
                    "Pedido vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Fecha de entrega
        if (fechaEntregaSeleccionada == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione la fecha de entrega usando el botón 📅.",
                    "Fecha faltante", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!fechaEntregaSeleccionada.isAfter(LocalDate.now().minusDays(1))) {
            JOptionPane.showMessageDialog(this,
                    "La fecha de entrega debe ser hoy o posterior.",
                    "Fecha inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente cliente    = (Cliente) cbClientes.getSelectedItem();
        String observaciones = txtObservaciones.getText().trim();

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "¿Confirma guardar el pedido para " + cliente + "?",
                "Confirmar guardado", JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        boolean ok = pedidoService.guardarPedido(
                cliente.getIdCliente(),
                Date.valueOf(fechaEntregaSeleccionada),
                observaciones,
                detallesTemp
        );

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "¡Pedido guardado correctamente!",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (pedidoFrame != null) pedidoFrame.cargarDatos();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar el pedido. Intente nuevamente.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Label total de UNIDADES ───────────────────────────
    private void actualizarTotal() {
        int totalUnidades = detallesTemp.stream()
                .mapToInt(DetallePedido::getCantidad)
                .sum();
        lblTotal.setText("Total de unidades: " + totalUnidades
                + "  |  Ítems en pedido: " + detallesTemp.size());
    }

    // ════════════════════════════════════════════════════
    //  CARGA DE DATOS
    // ════════════════════════════════════════════════════

    private void cargarClientes() {
        cbClientes.removeAllItems();
        cbClientes.addItem(null); // hint vacío
        for (Cliente c : clienteService.obtenerClientes()) {
            cbClientes.addItem(c);
        }
        cbClientes.setSelectedIndex(0);
    }

    private void cargarServicios() {
        cbServicios.removeAllItems();
        cbServicios.addItem(null); // hint vacío
        for (Servicio sv : servicioService.obtenerServicios()) {
            cbServicios.addItem(sv);
        }
        cbServicios.setSelectedIndex(0);
        // Inicializar tipos también vacíos
        cbTipos.removeAllItems();
        cbTipos.addItem(null);
        cbTipos.setSelectedIndex(0);
    }

    private void cargarTipos() {
        cbTipos.removeAllItems();
        cbTipos.addItem(null); // hint vacío
        Servicio sv = (Servicio) cbServicios.getSelectedItem();
        if (sv == null) {
            cbTipos.setSelectedIndex(0);
            return;
        }
        for (TipoDetalle t : servicioService.obtenerTiposPorServicio(sv.getIdServicio())) {
            cbTipos.addItem(t);
        }
        // Si hay tipos, dejar sin selección; si no, queda solo el null
        cbTipos.setSelectedIndex(0);
    }

    // ════════════════════════════════════════════════════
    //  UTILIDADES UI
    // ════════════════════════════════════════════════════

    private JButton crearBoton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        return b;
    }
}
