package com.megalab.service;

import com.megalab.dao.ServicioDAO;
import com.megalab.model.Servicio;
import com.megalab.model.TipoDetalle;

import java.util.List;

public class ServicioService {

    private ServicioDAO servicioDAO;

    public ServicioService() {
        servicioDAO = new ServicioDAO();
    }

    // ==========================
    // LISTAR SERVICIOS
    // ==========================

    public List<Servicio> obtenerServicios() {
        return servicioDAO.obtenerServicios();
    }

    // ==========================
    // TIPOS POR SERVICIO
    // ==========================

    public List<TipoDetalle> obtenerTiposPorServicio(int idServicio) {
        return servicioDAO.obtenerTiposPorServicio(idServicio);
    }
}
