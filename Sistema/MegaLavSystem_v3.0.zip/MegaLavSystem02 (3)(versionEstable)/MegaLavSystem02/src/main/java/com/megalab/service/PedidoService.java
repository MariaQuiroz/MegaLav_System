package com.megalab.service;

import com.megalab.dao.DetallePedidoDAO;
import com.megalab.dao.PedidoDAO;
import com.megalab.model.DetallePedido;
import com.megalab.model.Pedido;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class PedidoService {

    private PedidoDAO        pedidoDAO;
    private DetallePedidoDAO detalleDAO;

    public PedidoService() {
        pedidoDAO  = new PedidoDAO();
        detalleDAO = new DetallePedidoDAO();
    }

    // ==========================
    // GUARDAR PEDIDO NUEVO
    // ==========================

    public boolean guardarPedido(
            int idCliente,
            Date fechaEntrega,
            String observaciones,
            List<DetallePedido> detalles
    ) {
        if (detalles == null || detalles.isEmpty()) return false;

        Pedido pedido = new Pedido(
                0, idCliente,
                Date.valueOf(LocalDate.now()),
                fechaEntrega,
                "Pendiente",
                observaciones.isBlank() ? null : observaciones
        );

        int idPedido = pedidoDAO.insertarPedido(pedido);
        if (idPedido == -1) return false;

        for (DetallePedido d : detalles) {
            detalleDAO.insertarDetalle(new DetallePedido(
                    0, idPedido,
                    d.getIdServicio(), d.getIdTipo(), d.getCantidad()
            ));
        }
        return true;
    }

    // ==========================
    // CONSULTAS
    // ==========================

    public List<Pedido> obtenerPedidos() {
        return pedidoDAO.obtenerPedidos();
    }

    public Pedido buscarPorId(int idPedido) {
        return pedidoDAO.buscarPorId(idPedido);
    }

    public List<DetallePedido> obtenerDetallesPorPedido(int idPedido) {
        return detalleDAO.obtenerPorPedido(idPedido);
    }

    // ==========================
    // ACTUALIZAR ESTADO
    // ==========================

    public boolean actualizarEstado(int idPedido, String estado) {
        return pedidoDAO.actualizarEstado(idPedido, estado);
    }

    // ==========================
    // ACTUALIZAR FECHA Y OBS.
    // ==========================

    public boolean actualizarFechaYObservaciones(
            int idPedido,
            Date fechaEntrega,
            String observaciones
    ) {
        return pedidoDAO.actualizarFechaYObservaciones(
                idPedido, fechaEntrega,
                observaciones.isBlank() ? null : observaciones
        );
    }

    // ==========================
    // OPERACIONES DE DETALLES
    // ==========================

    public boolean eliminarDetallesPedido(int idPedido) {
        return detalleDAO.eliminarPorPedido(idPedido);
    }

    public boolean insertarDetalle(DetallePedido detalle) {
        return detalleDAO.insertarDetalle(detalle);
    }

    // ==========================
    // ELIMINAR PEDIDO COMPLETO
    // ==========================

    public boolean eliminarPedido(int idPedido) {
        return pedidoDAO.eliminarPedido(idPedido);
    }
}
