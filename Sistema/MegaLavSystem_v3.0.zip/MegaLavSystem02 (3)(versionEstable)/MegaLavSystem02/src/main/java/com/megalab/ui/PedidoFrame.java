package com.megalab.ui;

import com.megalab.model.Cliente;
import com.megalab.model.DetallePedido;
import com.megalab.model.Pedido;
import com.megalab.model.Servicio;
import com.megalab.model.TipoDetalle;
import com.megalab.service.ClienteService;
import com.megalab.service.PedidoService;
import com.megalab.service.ServicioService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class PedidoFrame extends JFrame {

    private JTextField    txtBuscar;
    private JButton       btnNuevoPedido;
    private JButton       btnVerDetalle;
    private JButton       btnActualizarEstado;
    private JButton       btnVolver;

    private JTable        tablaPedidos;
    private DefaultTableModel modelo;

    private PedidoService   pedidoService   = new PedidoService();
    private ServicioService servicioService = new ServicioService();
    private ClienteService clienteService = new ClienteService();

    private static final String[] ESTADOS = {
            "Pendiente", "En proceso", "Listo", "Entregado", "Cancelado"
    };

    // ════════════════════════════════════════════════════
    //  Constructor
    // ════════════════════════════════════════════════════

    public PedidoFrame() {

        setTitle("MegaLav System - Gestión de Pedidos");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fondo = new Color(245, 247, 250);
        Color texto = new Color(44, 62, 80);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(fondo);

        // ── HEADER ────────────────────────────────────────
        JPanel header = new JPanel();
        header.setBackground(fondo);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titulo    = new JLabel("GESTIÓN DE PEDIDOS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titulo.setForeground(texto);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Administración y seguimiento de pedidos");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitulo.setForeground(Color.GRAY);
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(titulo);
        header.add(Box.createVerticalStrut(10));
        header.add(subtitulo);

        // ── PANEL SUPERIOR ────────────────────────────────
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(fondo);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.setBackground(fondo);
        panelBusqueda.add(new JLabel("Buscar por cliente o estado:"));
        txtBuscar = new JTextField(25);
        panelBusqueda.add(txtBuscar);
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.addActionListener(e -> filtrarTabla(txtBuscar.getText().trim()));
        panelBusqueda.add(btnBuscar);
        JButton btnRefrescar = new JButton("↻ Refrescar");
        btnRefrescar.addActionListener(e -> { txtBuscar.setText(""); cargarDatos(); });
        panelBusqueda.add(btnRefrescar);

        JPanel panelNuevo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelNuevo.setBackground(fondo);
        btnNuevoPedido = new JButton("➕ Nuevo Pedido");
        btnNuevoPedido.setBackground(new Color(46, 204, 113));
        btnNuevoPedido.setForeground(Color.WHITE);
        btnNuevoPedido.setFocusPainted(false);
        btnNuevoPedido.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panelNuevo.add(btnNuevoPedido);

        panelSuperior.add(panelBusqueda, BorderLayout.WEST);
        panelSuperior.add(panelNuevo,    BorderLayout.EAST);

        // ── TABLA ─────────────────────────────────────────
        modelo = new DefaultTableModel(
                new String[]{"ID", "Cliente", "Fecha Registro", "Fecha Entrega", "Estado", "Observaciones"},
                0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaPedidos = new JTable(modelo);
        tablaPedidos.setRowHeight(30);
        tablaPedidos.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaPedidos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tablaPedidos.getTableHeader().setReorderingAllowed(false);
        tablaPedidos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Centrar columnas
        DefaultTableCellRenderer centro = new DefaultTableCellRenderer();
        centro.setHorizontalAlignment(SwingConstants.CENTER);
        for (int col : new int[]{0, 2, 3, 4}) {
            tablaPedidos.getColumnModel().getColumn(col).setCellRenderer(centro);
        }
        tablaPedidos.getColumnModel().getColumn(0).setMaxWidth(60);

        // Colores por estado
        tablaPedidos.getColumnModel().getColumn(4).setCellRenderer(
                new DefaultTableCellRenderer() {
                    @Override
                    public Component getTableCellRendererComponent(
                            JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                        super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                        setHorizontalAlignment(SwingConstants.CENTER);
                        if (!sel) {
                            String est = v != null ? v.toString() : "";
                            setBackground(switch (est) {
                                case "Pendiente"  -> new Color(255, 243, 205);
                                case "En proceso" -> new Color(207, 226, 255);
                                case "Listo"      -> new Color(212, 237, 218);
                                case "Entregado"  -> new Color(220, 220, 220);
                                case "Cancelado"  -> new Color(248, 215, 218);
                                default           -> Color.WHITE;
                            });
                        }
                        return this;
                    }
                }
        );

        JScrollPane scroll = new JScrollPane(tablaPedidos);

        // ── BOTONES INFERIORES ────────────────────────────
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.setBackground(fondo);

        btnVerDetalle      = new JButton("📋 Ver Detalle");
        btnActualizarEstado = new JButton("🔄 Actualizar Estado");
        btnVolver           = new JButton("← Volver");

        btnVerDetalle.setEnabled(false);
        btnActualizarEstado.setEnabled(false);

        panelBotones.add(btnVerDetalle);
        panelBotones.add(btnActualizarEstado);
        panelBotones.add(btnVolver);

        // ── ENSAMBLADO ────────────────────────────────────
        JPanel centroPanel = new JPanel(new BorderLayout(10, 10));
        centroPanel.setBackground(fondo);
        centroPanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        centroPanel.add(panelSuperior, BorderLayout.NORTH);
        centroPanel.add(scroll,        BorderLayout.CENTER);
        centroPanel.add(panelBotones,  BorderLayout.SOUTH);

        principal.add(header,      BorderLayout.NORTH);
        principal.add(centroPanel, BorderLayout.CENTER);
        add(principal);

        // ── EVENTOS ───────────────────────────────────────
        btnNuevoPedido.addActionListener(e ->
                new PedidoFormFrame(this).setVisible(true));

        tablaPedidos.getSelectionModel().addListSelectionListener(e -> {
            boolean sel = tablaPedidos.getSelectedRow() != -1;
            btnVerDetalle.setEnabled(sel);
            btnActualizarEstado.setEnabled(sel);
        });

        btnVerDetalle.addActionListener(e -> verDetalle());
        btnActualizarEstado.addActionListener(e -> actualizarEstado());
        btnVolver.addActionListener(e -> dispose());
        txtBuscar.addActionListener(e -> filtrarTabla(txtBuscar.getText().trim()));

        cargarDatos();
    }

    // ════════════════════════════════════════════════════
    //  CARGAR / FILTRAR
    // ════════════════════════════════════════════════════

    public void cargarDatos() {
        modelo.setRowCount(0);
        for (Pedido p : pedidoService.obtenerPedidos()) {
            String nombreCliente = p.getNombreCliente() != null
                    ? p.getNombreCliente() : "ID: " + p.getIdCliente();
            modelo.addRow(new Object[]{
                    p.getIdPedido(), nombreCliente,
                    p.getFechaRegistro(), p.getFechaEntrega(),
                    p.getEstado(),
                    p.getObservaciones() != null ? p.getObservaciones() : ""
            });
        }
    }

    private void filtrarTabla(String filtro) {
        modelo.setRowCount(0);
        for (Pedido p : pedidoService.obtenerPedidos()) {
            String nombreCliente = p.getNombreCliente() != null
                    ? p.getNombreCliente() : "ID: " + p.getIdCliente();
            if (filtro.isEmpty()
                    || nombreCliente.toLowerCase().contains(filtro.toLowerCase())
                    || p.getEstado().toLowerCase().contains(filtro.toLowerCase())) {
                modelo.addRow(new Object[]{
                        p.getIdPedido(), nombreCliente,
                        p.getFechaRegistro(), p.getFechaEntrega(),
                        p.getEstado(),
                        p.getObservaciones() != null ? p.getObservaciones() : ""
                });
            }
        }
    }

    // ════════════════════════════════════════════════════
    //  VER DETALLE (con botón EDITAR)
    // ════════════════════════════════════════════════════

    private void verDetalle() {

        int fila = tablaPedidos.getSelectedRow();
        if (fila == -1) return;

        int    idPedido = (int)    modelo.getValueAt(fila, 0);
        String cliente  = (String) modelo.getValueAt(fila, 1).toString();
        String estado   = (String) modelo.getValueAt(fila, 4).toString();
        String obsActual = modelo.getValueAt(fila, 5).toString();

        List<DetallePedido> detalles = pedidoService.obtenerDetallesPorPedido(idPedido);

        // ── Tabla de detalles ─────────────────────────────
        DefaultTableModel modeloDet = new DefaultTableModel(
                new String[]{"Servicio", "Tipo / Prenda", "Cantidad"}, 0
        );
        for (DetallePedido d : detalles) {
            modeloDet.addRow(new Object[]{
                    d.getNombreServicio(), d.getNombreTipo(), d.getCantidad()
            });
        }

        JTable tablaDet = new JTable(modeloDet);
        tablaDet.setRowHeight(26);
        tablaDet.setEnabled(false);
        tablaDet.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaDet.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        JScrollPane scrollDet = new JScrollPane(tablaDet);
        scrollDet.setPreferredSize(new Dimension(520, 200));

        // ── Info básica ───────────────────────────────────
        JPanel panelInfo = new JPanel(new GridLayout(3, 2, 10, 5));
        panelInfo.setBorder(new EmptyBorder(0, 0, 10, 0));
        panelInfo.add(new JLabel("Pedido #:")); panelInfo.add(new JLabel(String.valueOf(idPedido)));
        panelInfo.add(new JLabel("Cliente:"));  panelInfo.add(new JLabel(cliente));
        panelInfo.add(new JLabel("Estado:"));   panelInfo.add(new JLabel(estado));

        // ── Botón EDITAR ──────────────────────────────────
        JButton btnEditar = new JButton("✏ Editar Pedido");
        btnEditar.setBackground(new Color(52, 152, 219));
        btnEditar.setForeground(Color.WHITE);
        btnEditar.setFocusPainted(false);
        btnEditar.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JPanel panelBotonEditar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotonEditar.add(btnEditar);

        // ── Ensamblado diálogo ────────────────────────────
        JPanel contenido = new JPanel(new BorderLayout(0, 10));
        contenido.add(panelInfo,        BorderLayout.NORTH);
        contenido.add(scrollDet,        BorderLayout.CENTER);
        contenido.add(panelBotonEditar, BorderLayout.SOUTH);

        // Creamos el diálogo manualmente para poder referenciar su cierre
        JDialog dlg = new JDialog(this, "Detalle del Pedido #" + idPedido, true);
        dlg.setContentPane(contenido);
        dlg.pack();
        dlg.setLocationRelativeTo(this);

        // Evento editar: cierra detalle y abre editor
        btnEditar.addActionListener(ev -> {
            dlg.dispose();
            abrirEditorPedido(idPedido, cliente, obsActual, detalles);
        });

        dlg.setVisible(true);
    }

    // ════════════════════════════════════════════════════
    //  EDITOR DE PEDIDO (nuevo diálogo con formulario)
    // ════════════════════════════════════════════════════

    private void abrirEditorPedido(
            int idPedido,
            String nombreCliente,
            String obsActual,
            List<DetallePedido> detallesActuales
    ) {
        JDialog dlgEdit = new JDialog(this, "Editar Pedido #" + idPedido, true);
        dlgEdit.setSize(900, 680);
        dlgEdit.setLocationRelativeTo(this);
        dlgEdit.setResizable(true);

        Color fondo = new Color(245, 247, 250);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(fondo);
        root.setBorder(new EmptyBorder(15, 20, 15, 20));

        // ── Encabezado ────────────────────────────────────
        JLabel lblTitulo = new JLabel("Editando Pedido #" + idPedido + " — " + nombreCliente);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        // ── Observaciones ─────────────────────────────────
        JPanel panelObs = new JPanel(new BorderLayout(5, 5));
        panelObs.setBackground(Color.WHITE);
        panelObs.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Observaciones"),
                new EmptyBorder(5, 10, 5, 10)
        ));
        JTextArea txtObs = new JTextArea(3, 40);
        txtObs.setText(obsActual);
        txtObs.setLineWrap(true);
        txtObs.setWrapStyleWord(true);
        panelObs.add(new JScrollPane(txtObs), BorderLayout.CENTER);

        // ── Fecha entrega ─────────────────────────────────
        // Obtenemos la fecha actual del pedido desde la tabla
        int filaPedido = -1;
        for (int i = 0; i < modelo.getRowCount(); i++) {
            if ((int) modelo.getValueAt(i, 0) == idPedido) {
                filaPedido = i;
                break;
            }
        }

        final LocalDate[] fechaEntregaEdit = { null };
        Object fechaObj = filaPedido >= 0 ? modelo.getValueAt(filaPedido, 3) : null;
        if (fechaObj instanceof java.sql.Date fechaSql) {
            fechaEntregaEdit[0] = fechaSql.toLocalDate();
        }

        JTextField txtFechaEdit = new JTextField(
                fechaEntregaEdit[0] != null
                        ? fechaEntregaEdit[0].format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                        : "", 14
        );
        txtFechaEdit.setEditable(false);
        txtFechaEdit.setBackground(new Color(235, 235, 235));

        JButton btnCalEdit = new JButton("📅");
        btnCalEdit.addActionListener(e -> {
            LocalDate sel = mostrarCalendarioModal(dlgEdit, fechaEntregaEdit[0]);
            if (sel != null) {
                fechaEntregaEdit[0] = sel;
                txtFechaEdit.setText(sel.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            }
        });

        JPanel panelFecha = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelFecha.setBackground(Color.WHITE);
        panelFecha.add(new JLabel("Fecha Entrega:"));
        panelFecha.add(txtFechaEdit);
        panelFecha.add(btnCalEdit);

        JPanel panelEncima = new JPanel(new BorderLayout(5, 5));
        panelEncima.setBackground(Color.WHITE);
        panelEncima.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Datos del Pedido"),
                new EmptyBorder(5, 10, 5, 10)
        ));
        panelEncima.add(panelFecha, BorderLayout.NORTH);
        panelEncima.add(panelObs,   BorderLayout.CENTER);

        // ── Panel agregar servicio ─────────────────────────
        JComboBox<Servicio>    cbSv  = new JComboBox<>();
        JComboBox<TipoDetalle> cbTp  = new JComboBox<>();
        JTextField             txtCnt = new JTextField(6);
        txtCnt.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyTyped(java.awt.event.KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) e.consume();
            }
        });

        // Cargar servicios
        for (Servicio sv : servicioService.obtenerServicios()) cbSv.addItem(sv);
        cbSv.insertItemAt(null, 0); cbSv.setSelectedIndex(0);
        cbTp.insertItemAt(null, 0); cbTp.setSelectedIndex(0);

        cbSv.addActionListener(e -> {
            cbTp.removeAllItems();
            cbTp.addItem(null);
            Servicio sv = (Servicio) cbSv.getSelectedItem();
            if (sv != null) {
                for (TipoDetalle t : servicioService.obtenerTiposPorServicio(sv.getIdServicio()))
                    cbTp.addItem(t);
            }
            cbTp.setSelectedIndex(0);
        });

        JButton btnAddSv = new JButton("✚ Agregar");
        btnAddSv.setBackground(new Color(46, 204, 113));
        btnAddSv.setForeground(Color.WHITE);
        btnAddSv.setFocusPainted(false);

        JPanel panelAgregar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        panelAgregar.setBackground(Color.WHITE);
        panelAgregar.setBorder(BorderFactory.createTitledBorder("Agregar servicio"));
        panelAgregar.add(new JLabel("Servicio:")); panelAgregar.add(cbSv);
        panelAgregar.add(new JLabel("Tipo:"));     panelAgregar.add(cbTp);
        panelAgregar.add(new JLabel("Cantidad:")); panelAgregar.add(txtCnt);
        panelAgregar.add(btnAddSv);

        // ── Tabla detalles editable ────────────────────────
        List<DetallePedido> detallesEdit = new ArrayList<>(detallesActuales);

        DefaultTableModel modeloEdit = new DefaultTableModel(
                new String[]{"#", "Servicio", "Tipo", "Cantidad"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        for (int i = 0; i < detallesEdit.size(); i++) {
            DetallePedido d = detallesEdit.get(i);
            modeloEdit.addRow(new Object[]{
                    i + 1, d.getNombreServicio(), d.getNombreTipo(), d.getCantidad()
            });
        }

        JTable tablaEdit = new JTable(modeloEdit);
        tablaEdit.setRowHeight(26);
        tablaEdit.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaEdit.getColumnModel().getColumn(0).setMaxWidth(40);
        JScrollPane scrollEdit = new JScrollPane(tablaEdit);
        scrollEdit.setPreferredSize(new Dimension(0, 180));

        JLabel lblTotalEdit = new JLabel();
        Runnable actualizarTotalEdit = () -> {
            int tot = detallesEdit.stream().mapToInt(DetallePedido::getCantidad).sum();
            lblTotalEdit.setText("Total de unidades: " + tot + "  |  Ítems: " + detallesEdit.size());
        };
        actualizarTotalEdit.run();

        // Agregar detalle
        btnAddSv.addActionListener(e -> {
            Servicio sv = (Servicio) cbSv.getSelectedItem();
            TipoDetalle tp = (TipoDetalle) cbTp.getSelectedItem();
            if (sv == null || tp == null) {
                JOptionPane.showMessageDialog(dlgEdit, "Seleccione servicio y tipo.");
                return;
            }
            String cStr = txtCnt.getText().trim();
            if (cStr.isEmpty()) {
                JOptionPane.showMessageDialog(dlgEdit, "Ingrese la cantidad.");
                return;
            }
            int cnt;
            try {
                cnt = Integer.parseInt(cStr);
                if (cnt <= 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlgEdit, "Cantidad debe ser entero > 0.");
                return;
            }
            DetallePedido nd = new DetallePedido(
                    sv.getIdServicio(), tp.getIdTipo(), cnt,
                    sv.getNombre(), tp.getNombre()
            );
            detallesEdit.add(nd);
            modeloEdit.addRow(new Object[]{detallesEdit.size(), sv.getNombre(), tp.getNombre(), cnt});
            actualizarTotalEdit.run();
            txtCnt.setText("");
        });

        // Botón eliminar fila
        JButton btnDelFila = new JButton("✖ Eliminar ítem");
        btnDelFila.setBackground(new Color(231, 76, 60));
        btnDelFila.setForeground(Color.WHITE);
        btnDelFila.setFocusPainted(false);
        btnDelFila.addActionListener(e -> {
            int fr = tablaEdit.getSelectedRow();
            if (fr == -1) {
                JOptionPane.showMessageDialog(dlgEdit, "Seleccione un ítem para eliminar.");
                return;
            }
            detallesEdit.remove(fr);
            modeloEdit.removeRow(fr);
            for (int i = 0; i < modeloEdit.getRowCount(); i++)
                modeloEdit.setValueAt(i + 1, i, 0);
            actualizarTotalEdit.run();
        });

        JPanel panelTablaEdit = new JPanel(new BorderLayout(0, 4));
        panelTablaEdit.setBackground(fondo);
        panelTablaEdit.add(scrollEdit,  BorderLayout.CENTER);
        JPanel panelTotalDel = new JPanel(new BorderLayout());
        panelTotalDel.setBackground(fondo);
        panelTotalDel.add(lblTotalEdit, BorderLayout.WEST);
        panelTotalDel.add(btnDelFila,   BorderLayout.EAST);
        panelTablaEdit.add(panelTotalDel, BorderLayout.SOUTH);

        // ── Botones guardar/cancelar ───────────────────────
        JButton btnGuardarEdit = new JButton("💾 Guardar Cambios");
        btnGuardarEdit.setBackground(new Color(52, 152, 219));
        btnGuardarEdit.setForeground(Color.WHITE);
        btnGuardarEdit.setFocusPainted(false);
        btnGuardarEdit.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JButton btnCancelEdit = new JButton("Cancelar");
        btnCancelEdit.addActionListener(e -> dlgEdit.dispose());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));
        panelBotones.setBackground(fondo);
        panelBotones.add(btnGuardarEdit);
        panelBotones.add(btnCancelEdit);

        // ── Guardar cambios ────────────────────────────────
        btnGuardarEdit.addActionListener(e -> {

            if (detallesEdit.isEmpty()) {
                JOptionPane.showMessageDialog(dlgEdit,
                        "El pedido debe tener al menos un servicio.");
                return;
            }
            if (fechaEntregaEdit[0] == null) {
                JOptionPane.showMessageDialog(dlgEdit,
                        "Seleccione la fecha de entrega.");
                return;
            }
            if (fechaEntregaEdit[0].isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(dlgEdit,
                        "La fecha de entrega no puede ser anterior a hoy.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(dlgEdit,
                    "¿Confirma guardar los cambios del pedido #" + idPedido + "?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            // 1) Eliminar detalles viejos
            pedidoService.eliminarDetallesPedido(idPedido);

            // 2) Insertar detalles nuevos
            for (DetallePedido d : detallesEdit) {
                DetallePedido dGuardar = new DetallePedido(
                        0, idPedido,
                        d.getIdServicio(), d.getIdTipo(), d.getCantidad()
                );
                pedidoService.insertarDetalle(dGuardar);
            }

            // 3) Actualizar fecha y observaciones
            pedidoService.actualizarFechaYObservaciones(
                    idPedido,
                    Date.valueOf(fechaEntregaEdit[0]),
                    txtObs.getText().trim()
            );

            JOptionPane.showMessageDialog(dlgEdit,
                    "¡Pedido actualizado correctamente!",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);

            dlgEdit.dispose();
            cargarDatos();
        });

        // ── Ensamblado ────────────────────────────────────
        JPanel centroEdit = new JPanel(new BorderLayout(10, 10));
        centroEdit.setBackground(fondo);
        centroEdit.add(panelEncima,    BorderLayout.NORTH);
        centroEdit.add(panelAgregar,   BorderLayout.CENTER);

        JPanel abajo = new JPanel(new BorderLayout(10, 10));
        abajo.setBackground(fondo);
        abajo.add(panelTablaEdit, BorderLayout.CENTER);
        abajo.add(panelBotones,   BorderLayout.SOUTH);

        root.add(lblTitulo,  BorderLayout.NORTH);
        root.add(centroEdit, BorderLayout.CENTER);
        root.add(abajo,      BorderLayout.SOUTH);

        dlgEdit.setContentPane(root);
        dlgEdit.setVisible(true);
    }

    // ════════════════════════════════════════════════════
    //  CALENDARIO MODAL REUTILIZABLE
    // ════════════════════════════════════════════════════

    private LocalDate mostrarCalendarioModal(JDialog parent, LocalDate inicial) {

        final LocalDate[] resultado = { null };

        JDialog dlg = new JDialog(parent, "Seleccionar Fecha", true);
        dlg.setSize(320, 280);
        dlg.setLocationRelativeTo(parent);
        dlg.setResizable(false);

        Calendar cal = Calendar.getInstance();
        if (inicial != null) {
            cal.set(inicial.getYear(), inicial.getMonthValue() - 1, inicial.getDayOfMonth());
        }

        int anioActual = cal.get(Calendar.YEAR);
        SpinnerNumberModel modeloAnio = new SpinnerNumberModel(anioActual, anioActual, anioActual + 5, 1);
        JSpinner spinAnio = new JSpinner(modeloAnio);

        String[] meses = {"Enero","Febrero","Marzo","Abril","Mayo","Junio",
                "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        JComboBox<String> cbMes = new JComboBox<>(meses);
        cbMes.setSelectedIndex(cal.get(Calendar.MONTH));

        JPanel panelNav = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        panelNav.add(cbMes); panelNav.add(spinAnio);

        JPanel gridDias = new JPanel(new GridLayout(0, 7, 4, 4));
        gridDias.setBorder(new EmptyBorder(4, 10, 4, 10));

        for (String d : new String[]{"D","L","M","M","J","V","S"}) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            gridDias.add(lbl);
        }

        Runnable rellenar = () -> {
            int total = gridDias.getComponentCount();
            for (int i = total - 1; i >= 7; i--) gridDias.remove(i);

            int anio = (int) spinAnio.getValue();
            int mes  = cbMes.getSelectedIndex();

            Calendar tmp = Calendar.getInstance();
            tmp.set(anio, mes, 1);
            int primerDia = tmp.get(Calendar.DAY_OF_WEEK) - 1;
            int totalDias = tmp.getActualMaximum(Calendar.DAY_OF_MONTH);

            for (int i = 0; i < primerDia; i++) gridDias.add(new JLabel(""));

            LocalDate hoy = LocalDate.now();

            for (int dia = 1; dia <= totalDias; dia++) {
                final int d = dia;
                LocalDate fd = LocalDate.of(anio, mes + 1, dia);
                JButton btn = new JButton(String.valueOf(dia));
                btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                btn.setFocusPainted(false);
                btn.setMargin(new Insets(2, 2, 2, 2));

                if (fd.isBefore(hoy)) {
                    btn.setEnabled(false);
                    btn.setBackground(new Color(230, 230, 230));
                } else {
                    btn.addActionListener(ev -> {
                        resultado[0] = LocalDate.of((int) spinAnio.getValue(),
                                cbMes.getSelectedIndex() + 1, d);
                        dlg.dispose();
                    });
                }
                gridDias.add(btn);
            }
            gridDias.revalidate();
            gridDias.repaint();
        };

        rellenar.run();
        spinAnio.addChangeListener(e -> rellenar.run());
        cbMes.addActionListener(e -> rellenar.run());

        dlg.setLayout(new BorderLayout());
        dlg.add(panelNav,                 BorderLayout.NORTH);
        dlg.add(new JScrollPane(gridDias), BorderLayout.CENTER);
        dlg.setVisible(true);

        return resultado[0];
    }

    // ════════════════════════════════════════════════════
    //  ACTUALIZAR ESTADO
    // ════════════════════════════════════════════════════

    private void actualizarEstado() {

        int fila = tablaPedidos.getSelectedRow();
        if (fila == -1) return;

        int    idPedido     = (int)    modelo.getValueAt(fila, 0);
        String estadoActual =          modelo.getValueAt(fila, 4).toString();

        String nuevoEstado = (String) JOptionPane.showInputDialog(
                this,
                "Seleccione el nuevo estado para el Pedido #" + idPedido + ":",
                "Actualizar Estado",
                JOptionPane.QUESTION_MESSAGE,
                null, ESTADOS, estadoActual
        );

        if (nuevoEstado == null || nuevoEstado.equals(estadoActual)) return;

        boolean ok = pedidoService.actualizarEstado(idPedido, nuevoEstado);

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "Estado actualizado a: " + nuevoEstado,
                    "Actualización exitosa", JOptionPane.INFORMATION_MESSAGE);
            cargarDatos();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar el estado.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
